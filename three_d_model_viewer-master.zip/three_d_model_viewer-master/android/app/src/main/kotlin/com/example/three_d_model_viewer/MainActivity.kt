package com.example.three_d_model_viewer

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
